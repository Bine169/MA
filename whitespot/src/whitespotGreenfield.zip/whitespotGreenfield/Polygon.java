package whitespotGreenfield;

import java.util.List;

public class Polygon {

	public Integer id;
	public String geometry;
	public Double criteria;
	public List<Integer> neighbour;
	public Location allocatedLocation;
	
	public List<Integer> getNeighbours(){
		return neighbour;
	}
	
	public String getGeometry(){
		return this.geometry;
	}
	
	public Double getCriteria(){
		return this.criteria;
	}
	
	public int getId(){
		return this.id;
	}
	
	public void setNeighbours(List<Integer> neighbours){
		neighbour=neighbours;
	}
	
	public Location getAllocatedLocation(){
		return this.allocatedLocation;
	}
	
	public int getLocationId(){
		Location loc = getAllocatedLocation();
		return loc.getId();
	}
	
	public void setAllocatedLocation(Location loc){
		this.allocatedLocation=loc;
	}
	
}
