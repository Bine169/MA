package whitespotGreenfield;

import java.util.ArrayList;
import java.util.List;

public class LocationContainer {
	public List<Location> locations;
	
	public LocationContainer(){
		locations = new ArrayList<Location>();
	}
	
	public void add(int id, double lon, double lat){
		//init location
		Location loc = new Location();
		loc.id=id;
		loc.lon=lon;
		loc.lat=lat;
		
		//set Location to Container
		locations.add(loc);
		System.out.println("set Location "+id);
	}
	
	public Location getLocation(int id){
		return locations.get(id);
	}
	
	public void setHomePoly(int idLoc, int idPoly){
		Location loc = getLocation(idLoc);
		loc.idHomePoly=idPoly;
	}
	
	public void setAllocatedPolygon(Polygon poly, int idLocation){
		Location loc = getLocation(idLocation);
		loc.allocatedPolygon.add(poly);
	}
	
	public List<Polygon> getAllocatePolygon(int id){
		Location loc = locations.get(id);
		return loc.allocatedPolygon;
	}
}
