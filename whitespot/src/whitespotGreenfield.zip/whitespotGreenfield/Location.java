package whitespotGreenfield;

import java.util.ArrayList;
import java.util.List;

public class Location {
	public int id;
	public Double lon;
	public Double lat;
	public Integer idHomePoly;
	public List<Polygon> allocatedPolygon=new ArrayList<Polygon>();
	
	public int getId(){
		return this.id;
	}
	
	public int getHomePolyId(){
		return this.idHomePoly;
	}
	
	public void setAllocatedPolygon(Polygon poly){
		this.allocatedPolygon.add(poly);
	}
	
	public void removeAllocatedPolygon(Polygon poly){
		List<Polygon> allocatedPolys = this.allocatedPolygon;
		for (int i=0;i<allocatedPolys.size();i++){
			Polygon actPoly = allocatedPolys.get(i);
			if (actPoly.getId()==poly.getId()){
				this.allocatedPolygon.remove(i);
			}
		}
	}
}
