package whitespotGreenfield;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.io.BufferedReader;
import java.io.FileReader;


public class Functions {
	static LocationContainer locationContainer;
	static PolygonContainer polygonContainer;
	static ArrayList<Integer>[] rearrangedPolys = (ArrayList<Integer>[])new ArrayList[3];
	static int counterIdUsed=0;
	static boolean raiseThreshold=false;
	static int lastAreaSmallest;
	static int lastAreaBiggest;
	static int lastPolyID;
	static boolean nofoundBiggest=false;
	static boolean nofoundSmallest=false;
	static int nofoundlocbiggest=-1;
	static int nofoundlocsmallest=-1;
	static List<Integer> nofoundlocations = new ArrayList<Integer>(); 
	
	static double[] criteria;
	
	private static class polyDistances{
		static List<Integer> ids = new ArrayList<Integer>();
		static ArrayList<Double>[] distances;
	}
	
public static void allocatePolygonsByDistance(int numberpolygons, int numberlocations){
		
		for (int i=0;i<numberpolygons;i++){
			int locMinDist = 0;
			double minDistance = polyDistances.distances[i].get(0);
			for (int j=1;j<numberlocations;j++){
				if (polyDistances.distances[i].get(j)<minDistance){
					locMinDist=j;
					minDistance=polyDistances.distances[i].get(j);
				}
			}
			
			int polyID=polyDistances.ids.get(i);
			System.out.println("write "+polyID+" to "+(locMinDist+1));
			polygonContainer.setAllocatedLocation(i, locMinDist, locationContainer);
			
			System.out.println(i);
		}
		
	}

//	/**
//	 * Calculates the distance of the location to the actual polygon
//	 * @param location
//	 * @param geometry: geometry of the polygon to which the distance should be calculated
//	 * @param jdbc: JDBCConnection
//	 * @return double value of calculated distance
//	 * @throws SQLException
//	 */
	private static double calculateDist(StringBuffer sb, Statement stmt) throws SQLException{
		double distance;
		ResultSet d=stmt.executeQuery(sb.toString());
		d.next();
		distance=d.getDouble(1);
		
		return distance;
	}
	
	
	public static double calculateDistStCentroid(int i, String geometry, Statement stmt) throws SQLException{
		double distance;
		Location loc = locationContainer.getLocation(i);
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT ST_AsText(st_centroid(ST_GeomFromText('"+geometry+"')));");
		ResultSet d=stmt.executeQuery(sb.toString());
		d.next();
		String centroid=d.getString(1);
		sb = new StringBuffer();
		sb.append("SELECT st_distance(ST_GeomFromText('POINT("+loc.lon+" "+loc.lat+")'),ST_GeomFromText('"+centroid+"'));");
		distance = calculateDist(sb, stmt);
		
		return distance;
	}
	
	public static double calculateNeighbors(String geometrySource, String geometryTarget, Statement stmt) throws SQLException{
		double distance;
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT st_distance(ST_GeomFromText('"+geometrySource+"'),ST_GeomFromText('"+geometryTarget+"'));");
		distance = calculateDist(sb, stmt);
		return distance;
	}
	
	public static double[] changeCriteriaAfterRearrange(int polyID, int location, int locationMaxCriteria, double[] criteria, int numberpolygons) throws SQLException{
		//get criteria of the given polygon
		Polygon poly = polygonContainer.getPolygonById(numberpolygons, polyID);
		double critValue = poly.getCriteria();
			
			criteria[locationMaxCriteria-1]=criteria[locationMaxCriteria-1]-critValue;
			criteria[location-1]=criteria[location-1]+critValue;
			
		return criteria;
	}
	
public static void checkthresholdCombi(int numberpolygons,int numberlocations) throws Exception{
		
		boolean satisfied=false; 
		
		for(int i=0;i<rearrangedPolys.length;i++) rearrangedPolys[i] = new ArrayList<Integer>();
		
		lastAreaBiggest=-1;
		lastAreaSmallest=-1;
		int run=0;
		int threshold = 10;
		
		while (!satisfied){
			int[] compCriterias = new int[numberlocations];
			for (int i=0; i<numberlocations; i++) compCriterias[i]=0;
			
			for (int i=0; i<numberlocations;i++){
				for (int j=0;j<numberlocations;j++){
					if (j!=i){
						if (criteria[i]<criteria[j]){
							if (100-(criteria[j]*100/criteria[i])>-threshold)
								compCriterias[i]++;
						}
						else{
							if ((criteria[j]*100/criteria[i])-100< threshold)
								compCriterias[i]++;
						}

					}
				}
			}
			
			int no=0;
			boolean arranged=false;
			
			for (int i=0; i<numberlocations;i++){	
				if (compCriterias[i]!=(numberlocations-1) && !arranged && !nofoundlocations.contains(i)){
					
					if (run%2==1){
						System.out.println("biggest");
						rearrangeFromBiggest(numberlocations, numberpolygons);
					}
					else{
						System.out.println("smallest");
						rearrangeFromSmallest(numberlocations, numberpolygons);
					}
					
					if (counterIdUsed>=numberlocations){
						counterIdUsed=0;
						rearrangedPolys[0].clear();
						rearrangedPolys[1].clear();
						rearrangedPolys[2].clear();
						raiseThreshold=true;
					}
					
					arranged=true;
				}
				else no++;
			}
			run++;
			
			if (no==numberlocations){
				satisfied=true;
			}
			
			if (nofoundBiggest && nofoundSmallest){
				nofoundBiggest=false;
				nofoundSmallest=false;
				if (nofoundlocsmallest==nofoundlocbiggest){
					nofoundlocations.add(nofoundlocsmallest);
				}
			}
			
			
			if (raiseThreshold && !satisfied ){
				threshold=threshold+5;
				raiseThreshold=false;
				System.out.println("Threshold raised to "+threshold);
			}
			
			if (nofoundlocations.size()>=numberlocations){
				satisfied=true;
				System.out.println("Break");
			}
			
//			
//			FileWriter output =createFileWriter();
//			for (int i=0; i<numberlocations;i++){
//				writePolygon(output, allocPolys[i], geomAllocPolys[i],i+1);
//			}
//			output.close();
		}
		
		System.out.println("rearranged with a variance of "+threshold+"%");
		System.out.println("no better arrangement for "+nofoundlocations);
	}

	private static boolean checkUnitCalculationGives(int polyID, int loc, int numberpolygons) throws InterruptedException{
		boolean unit=false;
		
		//simpler to use buffPoly without polyID
		//List<Integer> buffAllocPolysLoc = new ArrayList<Integer>();
//		buffAllocPolysLoc=allocPolys[loc];
		
		//check unit of location that gives geometry
		//check unit if on polygone has no neighbour
		int nrNeighbours=0;
		int countAllocatedPolygons =0;
		
		for (int i=0; i<numberpolygons;i++){
			Polygon poly=polygonContainer.getPolygon(i);
			
			if (poly.getAllocatedLocation().getId()==loc){
				
				if (poly.getId()!=polyID){
					countAllocatedPolygons++;
					int actPoly = poly.getId();
						
					boolean neighbour=false;
					int pos=0;
					
					List<Integer> neighbours = poly.getNeighbours();
					while (!neighbour){	
						Polygon polyNeigh=polygonContainer.getPolygon(pos);
						if (polyNeigh.allocatedLocation.getId()==loc){
							for (int j=0;j<neighbours.size();j++){
								if (neighbours.get(j).equals(polyNeigh.getId()) && !neighbours.get(j).equals(actPoly) && poly.getId()!=polyID){
									neighbour=true;
									nrNeighbours++;
								}
							}	
						}
								
						pos++;
						if (pos>=numberpolygons){
							neighbour=true;
						}
					}
				}
			}
		}
		
		if ((nrNeighbours)==countAllocatedPolygons){
			unit=true;
		}
		
		//check unit by using graphs
		if (unit){
			int pos=0;
			boolean graphEnds = false;
			List<Integer> neighbours = new ArrayList<Integer>();
			List<Polygon> polysTaken = new ArrayList<Polygon>();
			List<Polygon> buffAllocPolysLoc = new ArrayList<Polygon>();
			for (int i=0;i<numberpolygons;i++){
				Polygon poly = polygonContainer.getPolygon(i);
				if (poly.getAllocatedLocation().getId()==loc){
					buffAllocPolysLoc.add(poly);
				}
			}
			
			for (int i=0;i<buffAllocPolysLoc.size();i++){
				if (buffAllocPolysLoc.get(i).getId()==polyID){
					buffAllocPolysLoc.remove(i);
				}
			}
			
			while (!graphEnds){
				Polygon actPoly = polygonContainer.getPolygon(pos);
				
				if (actPoly.getAllocatedLocation().getId()==loc && actPoly.getId()!=polyID){
					
					boolean takeNextNeighbour=false;
					if (neighbours.size()>0){
						if (actPoly.getId()==neighbours.get(0)){
							takeNextNeighbour=true;
							
						}
					}
					else{
						takeNextNeighbour=true;
					}
					
					if (takeNextNeighbour){
						boolean allreadyTaken=false;
						for (int i=0;i<polysTaken.size();i++){
							if (actPoly.getId()==polysTaken.get(i).getId()){
								allreadyTaken=true;
							}
						}
						
						if (!allreadyTaken){
							polysTaken.add(actPoly);
							
							for (int j=0;j<actPoly.getNeighbours().size();j++){
								for (int k=0;k<buffAllocPolysLoc.size();k++){
									if (buffAllocPolysLoc.get(k).getId()==actPoly.getNeighbours().get(j)){
							
										
										if (!neighbours.contains(buffAllocPolysLoc.get(k).getId())){
											neighbours.add(buffAllocPolysLoc.get(k).getId());
					
										}
									}
								}
							}
						}
						
						if (neighbours.size()>0){
							pos = 0;
							neighbours.remove(0);
						}
						else{
							graphEnds=true;
						}
						
					}
					else{
						pos++;
					}
				}
				else{
					pos++;
				}
			}
			
			int countPolysTaken=0;
			
			for (int j=0;j<polysTaken.size();j++){
				for (int k=0; k<buffAllocPolysLoc.size();k++){
					if (buffAllocPolysLoc.get(k).equals(polysTaken.get(j))){
						countPolysTaken++;
					}
				}
			}
			
			if (buffAllocPolysLoc.size()==countPolysTaken){
				unit=true;
			}
			else{
				unit=false;
			}
		}
		
		return unit;
	}
	
	public static boolean checkUnitCalculationGets(int polyID, int loc, int numberpolygons){
		boolean unit=false;
		
		//check unit of location that gets geometry
		
		//get Position of poly
		
		Polygon poly = polygonContainer.getPolygonById(numberpolygons, polyID);	
		boolean foundNeighbour=false;
		int counter=0;
		
		//check neighbours
		while(!foundNeighbour){
			//take all neighbours of poly
			for (int j=0; j<poly.getNeighbours().size();j++){
				//take all polys of location
				for (int k=0; k<numberpolygons;k++){
					Polygon actPoly = polygonContainer.getPolygon(k);
					if (actPoly.getAllocatedLocation().getId()==loc){
						if (poly.getNeighbours().get(j).equals(actPoly.getId())){
							unit=true;
							foundNeighbour=true;
						}
					}
				}
				counter++;
			}
			
			if (counter==poly.getNeighbours().size() && !foundNeighbour){
				foundNeighbour=true;
			}
		}
		
		return unit;
	}
	
	
	public static boolean checkUnit(int polyID, int locGive, int locGet, int numberpolygons) throws InterruptedException{
		boolean unit=false;
		
		boolean unitGives= checkUnitCalculationGives(polyID, locGive, numberpolygons);		
		boolean unitGets = checkUnitCalculationGets(polyID, locGet, numberpolygons);
		
		if (unitGets && unitGives){
			unit=true;
		}
		
		return unit; 
	}
	
	public static FileWriter createFileWriter() throws IOException{
		String filename = "polygones"+System.currentTimeMillis()+".csv";
		FileWriter output = new FileWriter(filename);
		output.append(new String("ID,Location"));
		output.append("\n");
		
		return output;
	}
	
	
	public static void createFileWriterLocs(int numberlocations) throws IOException{
		FileWriter outputloc = new FileWriter("locations.csv");
		outputloc.append(new String("ID, Long, Lat"));
		outputloc.append("\n");
		
		int coordpos=0;
		for (int i=1; i<(numberlocations+1);i++){
			Location loc = locationContainer.getLocation(i-1);
			outputloc.append(Objects.toString(i));
			outputloc.append(",");
			outputloc.append(Objects.toString(loc.lon));
			outputloc.append(",");
			outputloc.append(Objects.toString(loc.lat));
			outputloc.append("\n");
			coordpos=coordpos+2;
		}
		outputloc.close();
	}
	
	public static void determineHomePoly(boolean PLZ5, int numberlocations) throws SQLException{
		Statement jdbc = getConnection();
		String columnIDs=null;
		String tablegeom=null;
		String tablecrit=null;
		
		//PLZ5
		if (PLZ5){
			columnIDs="_g7304";
			tablegeom="geometriesplz5";
			tablecrit="criteriasplz5";
		}
		else{
		//PLZ8
			columnIDs="_g7305";
			tablegeom="geometriesplz8";
			tablecrit="criteriasplz8";
		}
		
		int id;
		StringBuffer sb = new StringBuffer();
		
		for (int i=0;i<numberlocations;i++){
			Location loc = locationContainer.getLocation(i);
			sb = new StringBuffer();
			//SELECT id FROM geometriesplz5 WHERE ST_Contains(the_geom,st_setsrid(st_makepoint(13.72047,51.09358),4326)) LIMIT 1;
			sb.append("SELECT id FROM "+tablegeom+" WHERE ST_Contains(the_geom,ST_Setsrid(ST_Makepoint("+loc.lon+","+loc.lat+"),4326)) LIMIT 1;");
			ResultSet d = jdbc.executeQuery(sb.toString());
			d.next();
			id = d.getInt(1);
			locationContainer.setHomePoly(i, id);
		}
	}
	
	public static Statement getConnection(){
		Connection jdbc = null;
		Statement stmt = null;
		try {
	         Class.forName("org.postgresql.Driver");
	         jdbc = DriverManager
	            .getConnection("jdbc:postgresql://localhost:5432/MA",
	            "postgres", "");
	      System.out.println("Opened database successfully");
	      stmt = jdbc.createStatement();
		}
	    catch ( Exception e ) {
	          System.err.println( e.getClass().getName()+": "+ e.getMessage() );
	          System.exit(0);
	    }
		
		return stmt;
	}
	
	public static ResultSet getNearestNeighbours(int polyID, String tablegeom, Statement jdbc) throws SQLException{
		//SELECT (pgis_fn_nn(p1.the_geom, 0.0005, 1000, 10, 'geometries', 'true', 'id', 'the_geom' )).nn_gid::int FROM (SELECT st_geomfromtext((Select st_astext(the_geom) FROM geometries WHERE ID=1), 4326) AS the_geom) AS p1;
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT (pgis_fn_nn(p1.the_geom, 0.0, 1000, 10, '"+tablegeom+"', 'true', 'id', 'the_geom' )).nn_gid::int FROM (SELECT st_geomfromtext((Select st_astext(the_geom) FROM "+tablegeom+" WHERE ID="+polyID+"), 4326) AS the_geom) AS p1;");
		ResultSet rNeighbours=jdbc.executeQuery(sb.toString());
		
		return rNeighbours;
	}
	
	//	
//	/**
//	 * calculates the number of polygons which are inside the Area; it is necessary to allocate all polygons
//	 * @return number of polygons
//	 * @throws SQLException
//	 */
	public static int getNrOrSum(boolean number, boolean PLZ5) throws SQLException, ClassNotFoundException{
		Statement jdbc = getConnection();
		StringBuffer sb = new StringBuffer();
		String table=null;
		if (PLZ5){
			table="criteriasplz5";
		}
		else{
			table="criteriasplz8";
		}
		
		if (number)
			{ sb.append("SELECT COUNT (id) FROM "+table+";");
			}
		else
			{ sb.append("SELECT SUM(CAST(_c1 AS int)) FROM criterias");}
		ResultSet t=jdbc.executeQuery(sb.toString());
		t.next();
		int sum=t.getInt(1);
		if (number)
			{System.out.println("numberofpolygons: "+sum);}
		else
			{System.out.println("sum: "+sum);}

		return sum;
	}
	
	public static void initCriteria(int numberpolygons, int numberlocations){
		criteria = new double[numberlocations];
		
		for (int i=0;i<numberpolygons;i++){
			double crit = polygonContainer.getPolygon(i).getCriteria();
			Location loc = polygonContainer.getAllocatedLocation(i);
			
			criteria[loc.id-1]=criteria[loc.id-1]+crit;
		}
	}
	
	public static void initDistances(int numberpolygons,int numberlocations) throws SQLException{
		Statement jdbc = functionsOld.getConnection();
		polyDistances.distances = (ArrayList<Double>[])new ArrayList[numberpolygons];
		for (int i=0; i<polyDistances.distances.length;i++) polyDistances.distances[i]=new ArrayList<Double>();

		for (int i=0;i<numberpolygons;i++){
			Polygon poly=polygonContainer.getPolygon(i);
			String geometry=poly.getGeometry();
			polyDistances.ids.add(poly.getId());
			
			for (int j=0; j<numberlocations;j++){
				double distance = calculateDistStCentroid(j, geometry, jdbc);
				polyDistances.distances[i].add(distance);
			}
		}
		
	}
	
	public static void initNeighbours(int numberpolygons, boolean PLZ5) throws SQLException{
		Statement jdbc = getConnection();
		String columnIDs=null;
		String tablegeom=null;
		String tablecrit=null;
				//PLZ5
				if (PLZ5){
					columnIDs="_g7304";
					tablegeom="geometriesplz5";
					tablecrit="criteriasplz5";
				}
				else{
				//PLZ8
					columnIDs="_g7305";
					tablegeom="geometriesplz8";
					tablecrit="criteriasplz8";
				}
				
		for (int i=0;i<numberpolygons;i++){
		
			List<Integer> neighbours = new ArrayList<Integer>();
			Polygon poly = polygonContainer.getPolygon(i);
			ResultSet nN = getNearestNeighbours(poly.getId(), tablegeom, jdbc);
			boolean last=false;
			while (!last){
				nN.next();
				neighbours.add(nN.getInt(1));
				if (nN.isLast()){last=true;}
			}
			
			poly.setNeighbours(neighbours);
		}
	}
	
	public static void initPolygones(int numberpolygons, int numberlocations, boolean PLZ5) throws SQLException{
		Statement jdbc = getConnection();
		String columnIDs=null;
		String tablegeom=null;
		String tablecrit=null;
				//PLZ5
				if (PLZ5){
					columnIDs="_g7304";
					tablegeom="geometriesplz5";
					tablecrit="criteriasplz5";
				}
				else{
				//PLZ8
					columnIDs="_g7305";
					tablegeom="geometriesplz8";
					tablecrit="criteriasplz8";
				}
		
		//get all PolygonIDs and store it
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT t2.id AS id, ST_AsTEXT(the_geom) AS the_geom, _c1 AS criteria FROM "+tablegeom+" AS t1 INNER JOIN "+tablecrit+" AS t2 ON t2."+columnIDs+"=t1.id");
		System.out.println(sb);
		ResultSet t=jdbc.executeQuery(sb.toString());
		
		polygonContainer = new PolygonContainer();
		
		//get ids, geometry and criteria
		for (int i=0;i<numberpolygons;i++){
				t.next();
				int id=t.getInt("id");
				String geometry=t.getString("the_geom");
				double criteria=t.getDouble("criteria");
				
				polygonContainer.add(id, geometry, criteria);			
		}
	}
	
	public static void rearrangeFromBiggest(int numberlocations, int numberpolygons) throws SQLException, Exception{

		double[] criteriaBuffer = new double[numberlocations];
		List<Integer> notNeighbouredPlys = new ArrayList<Integer>();
		
		for (int j=0; j<criteriaBuffer.length;j++){
			criteriaBuffer[j]=criteria[j];
		}
		
		
		for (int j = 0; j < criteriaBuffer.length - 1; j++)
        {
            int index = j;
            for (int k = j + 1; k < criteriaBuffer.length; k++)
                if (criteriaBuffer[k] > criteriaBuffer[index])
                    index = k;
            double greaterNumber = criteriaBuffer[index]; 
            criteriaBuffer[index] = criteriaBuffer[j];
            criteriaBuffer[j] = greaterNumber;
        }
		
		//criteriaBuffer[0] area with biggest critSum
		//detect neighbours of this area
		
		List<Integer> actNeighbours = new ArrayList<Integer>();
		int locBiggest=-1;
		
		//determine location with biggest critSum
		for (int j=0;j<numberlocations;j++){
			if (criteria[j]==criteriaBuffer[0]){
				locBiggest=j+1;
			}
		}
		
//		System.out.println("determine neigbours");
		//determine neighbours of area of location with biggest critSum
		for (int j=0;j<numberlocations;j++){
			if (j!=locBiggest){
				boolean neighbour=false;
				int pos=0;
				
//				System.out.println(locBiggest);
				
				while (pos<numberpolygons && neighbour==false){
					//check every allocated Polygone whether it is a neighbour of one of the polys of another location
					//take poly of locBiggest and check to every poly of loc
					
					Polygon poly = polygonContainer.getPolygon(pos);
//					System.out.println(poly.getLocationId()+","+(locBiggest+1));
					if (poly.getLocationId()==(locBiggest)){
						boolean neighbourfound=false;
						
						for(int k=0;k<numberpolygons;k++){
							Polygon comparePoly = polygonContainer.getPolygon(k);
							
//							System.out.println(comparePoly.getLocationId()+","+j);
							if (comparePoly.getLocationId()==(j+1)){
								List<Integer> neighbours = poly.getNeighbours();
//								System.out.println("compare "+comparePoly.getId()+" to "+poly.getId()+","+neighbours);
								for (int l=0;l<neighbours.size();l++){
									if (neighbours.get(l).equals(comparePoly.getId()) && !neighbourfound){
										neighbour=true;
										actNeighbours.add(j+1);
										neighbourfound=true;
									}
								}
							}
						}
						
						pos++;
					}
					else{
						pos++;
					}
						
				}
			}
		}
	
		//determine that area of neighbours areas with smallest critSum
		double minsum=-1;
		boolean first=true;
		int locMinsum=-1;
		
		for(int j=0;j<numberlocations;j++){
			boolean found=false;
			int posLoc=0;
			while (!found){
				if (actNeighbours.get(posLoc)==j && j!=lastAreaBiggest && !nofoundlocations.contains(j) && j!=nofoundlocbiggest){
					if (first){
						first=false;
						minsum=criteria[j];
						locMinsum=j;
					}
					else{
						if (criteria[j]<minsum){
							locMinsum=j;
							minsum=criteria[j];
						}
					}
					
					found=true;
				}
				if ((posLoc+1)<actNeighbours.size()){
					posLoc++;
				}
				else{
					found=true;
				}
			}
		}
		
		//give locMinSum 1 polygone of locbiggest
		
		int polyID = -1;
		double minDist=-1;
		
		boolean getStartPoly=false;
		boolean foundStartPoly=false;
		int pos=0;
		while (!getStartPoly){
			Polygon poly = polygonContainer.getPolygon(pos);
			if (poly.getAllocatedLocation().getId()==locBiggest){
				polyID=poly.getId();
				
				//check whether polyID is homepoly
				boolean homepoly=false;
				for (int i=0;i<numberlocations;i++){
					Location loc = locationContainer.getLocation(i);
					if (polyID==loc.getHomePolyId()){
						homepoly=true;
					}
				}
				
				if (!homepoly && polyID!=lastPolyID){					
					if (checkUnit(polyID,locBiggest,locMinsum, numberpolygons)){
						getStartPoly=true;
						minDist = polyDistances.distances[polyDistances.ids.indexOf(polyID)].get(locMinsum-1);
						foundStartPoly=true;
					}
					else{
						pos++;
					}
				}
				else{
					pos++;
				}
			}
			else{
				pos++;
			}
			

			if (pos==numberpolygons){
				getStartPoly=true;
			}
		}

		if (foundStartPoly){
		for (int l=1;l<numberpolygons;l++){
			Polygon poly = polygonContainer.getPolygon(l);
			
			if (poly.getAllocatedLocation().getId()==locBiggest){
				int buffpolyID=poly.getId();
				double actDist = polyDistances.distances[polyDistances.ids.indexOf(buffpolyID)].get(locMinsum-1);
				
				boolean homePoly=false;
				for (int i=0;i<numberlocations;i++){
					if (buffpolyID==locationContainer.getLocation(i).getHomePolyId())
						homePoly=true;
				}
				
				if (actDist<minDist && !homePoly){
					boolean unit = checkUnit(buffpolyID, locBiggest,locMinsum, numberpolygons);
					
					if (unit){
						minDist=actDist;
						polyID=buffpolyID;
					}
				}
		}
		}
		
		counterIdUsed=0;
		for (int k=0;k<rearrangedPolys[0].size();k++){
			if (rearrangedPolys[2].get(k).equals(locMinsum) && rearrangedPolys[1].get(k).equals(locBiggest) && rearrangedPolys[0].get(k).equals(polyID)){
				counterIdUsed++;
			}
		}
		
		lastAreaBiggest=locBiggest;
		
		rearrangedPolys[0].add(polyID);
		rearrangedPolys[1].add(locBiggest);
		rearrangedPolys[2].add(locMinsum);
		System.out.println(counterIdUsed);
		
		if (rearrangedPolys[0].size()>(numberlocations*numberlocations)){
			rearrangedPolys[0].remove(0);
			rearrangedPolys[1].remove(0);
			rearrangedPolys[2].remove(0);
		}
		
		//add polyID to locMinsum and remove from locbiggest
		lastPolyID=polyID;
		System.out.println("Set to "+(locMinsum)+" remove "+polyID+" from "+(locBiggest));
		
		Location locGets = locationContainer.getLocation(locMinsum-1);
		Location locGives = locationContainer.getLocation(locBiggest-1);
		Polygon polyMoves = polygonContainer.getPolygonById(numberpolygons, polyID);
		
		locGets.setAllocatedPolygon(polyMoves);
		locGives.removeAllocatedPolygon(polyMoves);
		polyMoves.setAllocatedLocation(locGets);

		
		criteria=changeCriteriaAfterRearrange(polyID, locMinsum, locBiggest, criteria, numberpolygons);
	
		}
		else{
			nofoundBiggest=true;
			nofoundlocbiggest=locMinsum;
		}
	}
	
	public static void rearrangeFromSmallest(int numberlocations, int numberpolygons) throws SQLException, InterruptedException{
		
		int locSmallestCritSum=-1;
		
		//init array for sorted critSums
		double[] criteriaBuffer = new double[numberlocations];
		for (int j=0; j<criteriaBuffer.length;j++){
			criteriaBuffer[j]=criteria[j];
		}
		
		//sort critSums
		for (int j = 0; j < criteriaBuffer.length - 1; j++)
        {
            int index = j;
            for (int k = j + 1; k < criteriaBuffer.length; k++)
                if (criteriaBuffer[k] < criteriaBuffer[index])
                    index = k;
            double greaterNumber = criteriaBuffer[index]; 
            criteriaBuffer[index] = criteriaBuffer[j];
            criteriaBuffer[j] = greaterNumber;
        }
		
		//determine area with smallest critSum
		boolean foundlocSmallestCritSum=false;
		int poslocSmallCritSum=0;
		
		while (!foundlocSmallestCritSum){
			
			for (int j=0;j<numberlocations;j++){
				if (criteriaBuffer[poslocSmallCritSum]==criteria[j]){
					locSmallestCritSum=j+1;
				}
			}
			
			if (!nofoundlocations.contains(locSmallestCritSum) && locSmallestCritSum!=nofoundlocsmallest){
				foundlocSmallestCritSum=true;
			}
			else{
				poslocSmallCritSum++;
			}
			
		}
		
		boolean getStartPoly=false;
		int pos=0;
		int polyID=-1;
		double minDistance=-1;
		boolean foundStartPoly=false;
		
		//determine startPoly for distance check
		while (!getStartPoly){
			Polygon actPoly = polygonContainer.getPolygon(pos);
			
			if (actPoly.getAllocatedLocation().getId()!=locSmallestCritSum){
				polyID=actPoly.getId();
				
				//determine location of polyID
				int locationremove = actPoly.getAllocatedLocation().getId();
				
				//check whether polyID is homePoly
				boolean homepoly=false;
				for (int i=0;i<numberlocations;i++){
					Location actLoc = locationContainer.getLocation(i);
					if (actLoc.getHomePolyId()==polyID){
						homepoly=true;
					}
				}
				
				if (locationremove!=locSmallestCritSum && !homepoly && polyID!=lastPolyID){
					if (checkUnit(polyID, locationremove, locSmallestCritSum, numberpolygons)){
						getStartPoly=true;
						minDistance=polyDistances.distances[polyDistances.ids.indexOf(polyID)].get(locSmallestCritSum-1);
						foundStartPoly=true;
					}
					else{
						pos++;
					}
				}
				else{
					pos++;
				}
			}
			else{
				pos++;
			}
			
			if (pos>=numberpolygons){
				getStartPoly=true;
			}
		}
		
		pos=0;
		
		if (foundStartPoly){
		for (int j=0;j<numberpolygons;j++){
			Polygon actPoly = polygonContainer.getPolygon(pos);
			
			if (actPoly.getAllocatedLocation().getId()!=locSmallestCritSum){
				double actdist=polyDistances.distances[polyDistances.ids.indexOf(actPoly.getId())].get(locSmallestCritSum-1);
				
				int locationremove=actPoly.getAllocatedLocation().getId();
				int buffpolyID=actPoly.getId();
				
				
				//check Unit if polyID will be rearranged	
				if (actdist<minDistance && buffpolyID!=locationContainer.getLocation(locationremove-1).getHomePolyId()){
					boolean unit = checkUnit(buffpolyID, locationremove, locSmallestCritSum, numberpolygons);
	
					if (unit){
						minDistance=actdist;
						polyID=buffpolyID;
					}
				}
			}
		}

		int locationremove=-1;
		for (int j=0;j<numberpolygons;j++){
			Polygon polyRemove = polygonContainer.getPolygon(j);
			if (polyRemove.getId()==polyID){
				locationremove = polyRemove.getAllocatedLocation().getId();
			}
		}
		
		counterIdUsed=0;
		for (int k=0;k<rearrangedPolys[0].size();k++){
			if (rearrangedPolys[2].get(k).equals(locSmallestCritSum) && rearrangedPolys[1].get(k).equals(locationremove) && rearrangedPolys[0].get(k).equals(polyID)){
				counterIdUsed++;
			}
		}
		
		rearrangedPolys[0].add(polyID);
		rearrangedPolys[1].add(locationremove);
		rearrangedPolys[2].add(locSmallestCritSum);
		
		if (rearrangedPolys[0].size()>(numberlocations*numberlocations)){
			rearrangedPolys[0].remove(0);
			rearrangedPolys[1].remove(0);
			rearrangedPolys[2].remove(0);
		}
		
		lastAreaSmallest=locSmallestCritSum;
		lastPolyID=polyID;
		System.out.println("Set to "+(locSmallestCritSum)+" remove "+polyID+" from "+(locationremove+1));
		
		Location locGets = locationContainer.getLocation(locSmallestCritSum-1);
		Location locGives = locationContainer.getLocation(locationremove-1);
		Polygon polyMoves = polygonContainer.getPolygonById(numberpolygons, polyID);
		
		locGets.setAllocatedPolygon(polyMoves);
		locGives.removeAllocatedPolygon(polyMoves);
		polyMoves.setAllocatedLocation(locGets);
		
		criteria=changeCriteriaAfterRearrange(polyID, locSmallestCritSum, locationremove, criteria, numberpolygons);
		
		}
		else{
			nofoundSmallest=true;
			nofoundlocsmallest=locSmallestCritSum;
		}
	}
	
	public static void setLocations(int numberlocations) throws IOException{
		locationContainer = new LocationContainer();
		
		//Input file which needs to be parsed
        String fileToParse = "E:\\Studium\\Master\\4.Semester - MA\\OSD_Standorte_MC.csv";
        BufferedReader fileReader = null;
         
        //Delimiter used in CSV file
        final String DELIMITER = ";";
        int pos=0;

		boolean satisfied=false;
		int i=0;
		List<Integer> ids = new ArrayList<Integer>();
//				ids.add(5);	//DD Weixdorf
//				ids.add(10); //DD Elbcenter
		ids.add(11); //DD Löbtau
//				ids.add(29);	//DD Seidnitz
//				ids.add(34); //DD Sparkassenhaus
//				ids.add(39);	 //DD Weißig
		ids.add(41); //Radeberg Hauptstr
//				ids.add(51); //Kesselsdorf
//				ids.add(54);	//Kreischa
		ids.add(55); //Rabenau
//				ids.add(56); //Tharandt
//				ids.add(60); //Altenberg
		ids.add(68); //Struppen
		ids.add(72);	//DD Heidenau West
//				ids.add(77);	//Bergießhübel
		ids.add(79);	//Liebstadt
		ids.add(82);	//Neustadt
		ids.add(90); //Panschwitz Kuckau
		ids.add(92); //Schwepnitz
		ids.add(96); //Hoyerswerda Altstadt
				
		String line = "";
	    //Create the file reader
	    fileReader = new BufferedReader(new FileReader(fileToParse));
	    line = fileReader.readLine();
	            
	            while (!satisfied){ 
	            	line = fileReader.readLine();
					
	            	if (line==null){
	            		satisfied=true;
	            	}
	            	else{
						//Get all tokens available in line
		                String[] tokens = line.split(DELIMITER);
						
						if (ids.contains(Integer.valueOf(tokens[0]))){
							i++;
							double lon = Double.parseDouble(tokens[7]);
							double lat = Double.parseDouble(tokens[8]);
							locationContainer.add(i, lon,lat);
							pos=pos+2;
						}
						
						if (i==numberlocations){satisfied=true;}
	            	}
				}
			
		fileReader.close();
	}


	public static void showCritResult(int numberlocations){
		for (int i=0;i<numberlocations;i++){
			System.out.println("Critsize location "+i+" :"+criteria[i]);
		}
	}
	
//	
//	/**
//	 * Write Polygons into shape, just necessary for testing purposes
//	 * @param buffershp: name of the ShapeBuffer
//	 * @param shpWriter: name of the ShapeWriter
//	 * @param bufferPoly: IDs of Polygons which belong/are allocated to the location
//	 * @param geomPoly: Geometries of Polygons which belong/are allocated to the location
//	 * @param location
//	 * @throws Exception
//	 */
	public static void writePolygon(FileWriter output, int numberlocations, int numberpolygons) throws Exception{
	for (int i=0;i<numberpolygons;i++){
			Polygon poly = polygonContainer.getPolygon(i);
			Location loc = polygonContainer.getAllocatedLocation(i);
			
			output.append(Objects.toString(poly.getId()));
			output.append(";");
			output.append(Objects.toString(loc.getId()));
			output.append("\n");	
	}
	}

	
}
