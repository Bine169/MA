package whitespotGreenfield;

import java.util.ArrayList;
import java.util.List;

public class PolygonContainer {
	private List<Polygon> polygons;
	
	public PolygonContainer(){
		polygons = new ArrayList<Polygon>();
	}
	
	public void add(int id, String geometry, double criteria){
		//init Polygon
		Polygon poly = new Polygon();
		poly.id=id;
		poly.geometry=geometry;
		poly.criteria=criteria;
		
		//set Polygon
		polygons.add(poly);
	}
	
	public Polygon getPolygon(int id){
		return polygons.get(id);
	}
	
	public Location getAllocatedLocation(int id){
		Polygon poly = polygons.get(id);
		return poly.allocatedLocation;
	}
	
	public void setNeighbours(int id, List<Integer> neighbours){
		Polygon poly = getPolygon(id);
		poly.neighbour=neighbours;
	}
	
	public void setAllocatedLocation(int idPoly, int idLocation, LocationContainer locationContainer){
		Polygon poly = getPolygon(idPoly);
		Location loc = locationContainer.getLocation(idLocation);
		poly.allocatedLocation=loc;
		locationContainer.setAllocatedPolygon(poly,idLocation);
	}
	
	public Polygon getPolygonById(int numberpolygons, int polyID){
		Polygon poly=new Polygon();
		for (int i=0;i<numberpolygons;i++){
			Polygon actPoly=getPolygon(i);
			if (actPoly.getId()==polyID){
				poly=actPoly;
			}
		}
		
		return poly;
	}
	
}
