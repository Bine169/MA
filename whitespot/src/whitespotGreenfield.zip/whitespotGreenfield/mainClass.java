package whitespotGreenfield;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

public class mainClass {
	
	public static void main(String[] args)
			throws Exception {
		
		boolean PLZ5=true;
		boolean common=true;
		
		long time = System.currentTimeMillis();
		int numberlocations=10;
		Functions.setLocations(numberlocations);
		
		//create FileWriter
		FileWriter output =Functions.createFileWriter();
		Functions.createFileWriterLocs(numberlocations);
		
		//init variables
		double[] criteria = new double[numberlocations];
		for (int i=0; i<numberlocations;i++){
			criteria[i]=0;
		}
		
		//calculate number of Polygons in that region
		int numberpolygons=Functions.getNrOrSum(true, PLZ5);
		
		//init polys: get id, geometry, criteria
		Functions.initPolygones(numberpolygons, numberlocations, PLZ5);
		
		//init neighbours
		Functions.initNeighbours(numberpolygons, PLZ5);
		
		//init homePolys
		Functions.determineHomePoly(PLZ5, numberlocations);
		
		//determine distances between poly and locations
		Functions.initDistances(numberpolygons, numberlocations);
		
		//allocate geometries to locations dependent on distance
		Functions.allocatePolygonsByDistance(numberpolygons, numberlocations);
		
		//sum criterias of allocated geometries
		Functions.initCriteria(numberpolygons, numberlocations);
		
		//check threshold value
		Functions.checkthresholdCombi(numberpolygons, numberlocations);
		
		//write Polygons
		Functions.writePolygon(output, numberlocations, numberpolygons);
		
		Functions.showCritResult(numberlocations);
		
		System.out.println("Time for whole algorithm:"+(System.currentTimeMillis()-time)+" ms");
//		
		output.flush();
		output.close();
	    
	    System.out.println("successfully ended");
		//welche Funktionen in functionsnew �berhaupt noch notwendig? welche variablen?
		
	}
}
